import { Roles } from './roles';

describe('Roles', () => {
  it('should create an instance', () => {
    expect(new Roles()).toBeTruthy();
  });
});
