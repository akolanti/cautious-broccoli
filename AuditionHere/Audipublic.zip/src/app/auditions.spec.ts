import { Auditions } from './auditions';

describe('Auditions', () => {
  it('should create an instance', () => {
    expect(new Auditions()).toBeTruthy();
  });
});
