export class Actordata {
    _id: String;
    userName:String;
        firstName:String;
        lastName:String;
        actorHeight:Number;
        actorWeight:Number;
        actorBirthDate:Date;
        actorEthinicity:String;
        actorEyeColor:String;
        actorSkills:Array<String>;
        actorActingCredits:Array<String>;
        actorOtherData:Array<ImageBitmap>;
}
