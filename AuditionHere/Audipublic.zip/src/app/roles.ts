export class Roles {
    name:String;
    age:String;
    gender:String;
    description:String;
    height:String;
    color:string;
    ethnicity:string;

}
