import {Roles} from "./roles"
export class Auditions {
    _id: String;
    title:String;
        location:String;
        type:String;
        description:string;
        lastdate:Date;
        roles:Roles
}
