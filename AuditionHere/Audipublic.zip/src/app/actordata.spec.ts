import { Actordata } from './actordata';

describe('Actordata', () => {
  it('should create an instance', () => {
    expect(new Actordata()).toBeTruthy();
  });
});
